<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getUsers, createUser } from '@/api/client'

const users = ref<any[]>([])
const name = ref('')

async function loadUsers() {
  users.value = await getUsers()
}

async function addUser() {
  if (!name.value) return
  await createUser({ name: name.value })
  name.value = ''
  loadUsers()
}

onMounted(loadUsers)
</script>

<template>
  <div>
    <h2>Users</h2>

    <input v-model="name" placeholder="Enter name" />
    <button @click="addUser">Add</button>

    <ul>
      <li v-for="user in users" :key="user.id">
        {{ user.name }}
      </li>
    </ul>
  </div>
</template>
